@echo off
setlocal enabledelayedexpansion

for /f "delims=" %%i in ('git describe --tags --abbrev^=0 2^>nul') do set PREV_VERSION=%%i

if "!PREV_VERSION!"=="" (
    echo Error: No previous Git tags found in this repository.
    exit /b 1
)

echo Latest tag found: !PREV_VERSION!
echo Finding changed files since !PREV_VERSION!...

:: Build up the file list safely in Windows CMD
set "CHANGED_FILES="
for /f "delims=" %%f in ('git diff --name-only "!PREV_VERSION!"..HEAD') do (
    set "CHANGED_FILES=!CHANGED_FILES! "%%f""
)

if "!CHANGED_FILES!"=="" (
    echo No changes found since !PREV_VERSION!
    exit /b 0
)

echo Packaging modified files into mage-update.zip...
for /f "delims=" %%i in ('git diff --name-only "!PREV_VERSION!"..HEAD') do set "FILES_TO_ARCHIVE=!FILES_TO_ARCHIVE! %%i"

git archive -o mage-update.zip HEAD !FILES_TO_ARCHIVE!

echo Done! mage-update.zip has been created.