#!/bin/sh

java -Xmx1024m --add-opens=java.base/java.io=ALL-UNNAMED --add-opens=java.base/java.lang=ALL-UNNAMED --add-opens=java.base/java.util=ALL-UNNAMED -jar ./lib/mage-server-${project.version}.jar
