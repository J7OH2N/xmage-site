package mage.cards.custom;

import mage.abilities.keyword.HasteAbility;
import mage.cards.CardImpl;
import mage.cards.CardSetInfo;
import mage.constants.CardType;
import mage.constants.SubType;
import mage.MageInt;

import java.util.UUID;

/**
 * Glint-Eye Vanguard
 * {R} - 2/1 Red Elemental Warrior with Haste
 * 
 * @author Custom
 */
public final class GlintEyeVanguard extends CardImpl {

    public GlintEyeVanguard(UUID ownerId, CardSetInfo setInfo) {
        super(ownerId, setInfo, new CardType[]{CardType.CREATURE}, "{R}");
        
        this.subtype.add(SubType.ELEMENTAL);
        this.subtype.add(SubType.WARRIOR);
        this.power = new MageInt(2); // 2/1
        this.toughness = new MageInt(1);

        // Haste
        this.addAbility(HasteAbility.getInstance());
    }

    private GlintEyeVanguard(final GlintEyeVanguard card) {
        super(card);
    }

    @Override
    public GlintEyeVanguard copy() {
        return new GlintEyeVanguard(this);
    }
}
