package mage.sets.custom;

import mage.cards.ExpansionSet;
import mage.constants.Rarity;
import mage.constants.SetType;

/**
 * Custom set for your custom cards.
 * This set will be automatically loaded by XMage's class scanner.
 * 
 * @author YourName
 */
public final class MyCustomSet extends ExpansionSet {

    private static final MyCustomSet instance = new MyCustomSet();

    public static MyCustomSet getInstance() {
        return instance;
    }

    private MyCustomSet() {
        super("My Custom Set", "MCS", ExpansionSet.buildDate(2026, 7, 11), SetType.CUSTOM_SET);
        this.hasBoosters = false;
        this.hasBasicLands = false;

        // Add your custom cards here following this pattern:
        // cards.add(new SetCardInfo("Card Name", cardNumber, Rarity, mage.cards.package.CardClass.class));
        
        // Custom test card
        cards.add(new SetCardInfo("Glint-Eye Vanguard", 1, Rarity.UNCOMMON, mage.cards.custom.GlintEyeVanguard.class));
    }
}
